export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:./export_lib/
./server 127.0.0.1 8089\   # -- 可执行文件
# ./param1/param1.suffix \   # -- 参数一
# ./param2/param2.suffix \   # -- 参数二
# ...
